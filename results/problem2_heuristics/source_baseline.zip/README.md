# 实验二：搜索算法基础实现

四道题的可运行基础版本：手写 A*、Minimax、Alpha-Beta，以及组合使用它们的宝藏分配求解器。已完成官方用例、正确性检查、统计接口、题一“零启发 vs 曼哈顿”和题二“三种启发与可采纳性”的第一轮配对对照。其余对照、算法优化和最终实验报告留待后续完成。

## 1. 从这里开始运行

要求 **Python 3.10 或更新版本**。实现和测试仅使用标准库，无需安装第三方依赖。本次已在工作区的 Python 3.13 环境运行验证。

先在 PowerShell 进入项目根目录：

```powershell
Set-Location 'C:\Users\20921\Desktop\当代人工智能\实验二'
python -m src.main --case all
```

再运行正确性测试：

```powershell
python -m unittest discover -s tests -v
```

如果电脑上的 `python` 指向其他环境，可替换为 Python 可执行文件的绝对路径；无需使用 pytest。

## 2. 官方结果

| 题目 | 结果 |
|---|---|
| 题一 | 最短 7 步，路径含起终点共 8 个坐标 |
| 题二 | 最小移动代价 `7` |
| 题三 | Minimax 和 Alpha-Beta 根值均为 `5` |
| 题四 H=2 | 两种算法均为 `{"best_target": "T2", "best_value": -1}` |
| 题四 H=4 | 两种算法均为 `{"best_target": "T3", "best_value": 3}` |

题一默认顺序输出：

```text
[(0,0),(0,1),(0,2),(1,2),(1,3),(1,4),(2,4),(3,4)]
```

Python 纯函数返回 tuple 坐标；命令行使用标准 JSON，因此坐标显示为数组。其他等长合法路径同样符合题意。

题四的矩阵按 A、B、T1、T2、T3、T4 排列：

| 起点/终点 | A | B | T1 | T2 | T3 | T4 |
|---|---:|---:|---:|---:|---:|---:|
| A | 0 | 12 | 10 | 4 | 8 | 8 |
| B | 12 | 0 | 8 | 8 | 4 | 10 |
| T1 | 10 | 8 | 0 | 6 | 6 | 12 |
| T2 | 4 | 8 | 6 | 0 | 6 | 6 |
| T3 | 8 | 4 | 6 | 6 | 0 | 6 |
| T4 | 8 | 10 | 12 | 6 | 6 | 0 |

矩阵由 A* 动态计算，代码中没有硬编码此表或最终答案。非对角线逐对查询，不假定一般输入的进入代价矩阵对称。

## 3. 单独运行、统计与轨迹

```powershell
# 单题：默认读取 cases/ 中该题的官方输入
python -m src.main --problem 1
python -m src.main --problem 2
python -m src.main --problem 3
python -m src.main --problem 4

# 指定输入；修改 JSON 可测试其他地图或树
python -m src.main --problem 1 --input cases/problem1.json

# 题三分别运行两种算法；默认题三只输出 Alpha-Beta 的分数
python -m src.main --problem 3 --algorithm both --stats

# 题四指定深度/算法；默认同时计算 Minimax 与 Alpha-Beta
python -m src.main --problem 4 --depth 4 --algorithm alpha-beta --stats

# 保存四题结果；包含统计，单次耗时不是正式性能对照数据
python -m src.main --case all --stats --output results/official.json

# 搜索轨迹较长，建议保存后阅读
python -m src.main --problem 1 --trace --output results/problem1_trace.json
python -m src.main --problem 3 --trace --output results/problem3_trace.json
python -m src.main --problem 4 --depth 2 --trace --output results/problem4_trace.json
```

`--case all`（或不带参数运行）会同时运行四题，默认让题三、四都执行两种博弈算法。`--stats` 附加计数和一次搜索耗时；`--trace` 也包含统计。

非法命令或输入会给出错误消息并以退出码 2 结束。输入 JSON 支持 UTF-8，也兼容带 BOM 的 UTF-8。所有结果为 JSON，`--output` 指定路径的父目录会自动建立。

## 4. 每题实现了什么

### 题一：迷宫最短路径

入口在 `src/problem1_maze.py`。

- 仅允许上下左右移动；每步代价 1，X 不可进入。
- 用曼哈顿距离作为默认启发。优先队列先比 f，再比 h，最后比入堆序号。
- 维护最佳 g 和父指针；找到目标后回溯完整路径。
- 合法但无路返回 `[]`；起终点相同返回单点路径。

通用 A* 会跳过过期堆条目，并允许更好的路径重新打开已扩展状态。目标在有效出队时判断，避免发现目标就提前返回非最优路径。

### 题二：加权地形

入口在 `src/problem2_terrain.py`。

- 移动的代价是**进入格**的权值；初始位置不收费。
- 本题进入目标格的代价为 0，其他标记格按 1。
- 默认启发为 `m * max(0, Manhattan - 1)`，m 为非终点可通行格的最小进入代价。存在普通零权格时安全退化为零启发。
- 合法但无路返回 `-1`；起终点相同返回 0。
- 输入权值支持非负整数或表示非负整数的字符串；不接受浮点数、负数或 bool。

官方路径为下走三步、右走两步、下走一步、右走两步。进入 E 的最后一步为 0，所以 8 次移动合计 7。

详细接口保留 `zero`、`manhattan`、`corrected_manhattan` 三种启发选项供之后做对照；此阶段默认使用符合原题的修正启发，未加入精确启发预处理或加权 A*。

### 题三：极大极小博弈树

入口在 `src/game_tree.py`。

- `TreeNode` 兼容题目给出的 `value` 与 `children` 构建方式。
- 根为 MAX，逐层 MAX/MIN 交替；JSON 有显式玩家字段时会验证是否矛盾。
- Minimax 固定从左到右求值；Alpha-Beta 在同顺序下使用 `alpha >= beta` 截断。
- 支持共享子树的 DAG，但不启用缓存；同一对象被访问两次仍统计两次。
- 搜索前完整验证输入，拒绝环、没有分数的空节点及不合法叶值，避免非法子树因剪枝而被隐藏。

官方逻辑树的左 MIN 值为 5，右 MIN 值为 2，因此 MAX 根取 5。Alpha-Beta 在左 MIN 下第二个 MAX 看见 6 时，可以跳过该位置的 9。

轨迹记录进入、叶值、回传和剪枝。有限窗口截断的回传可能是界；轨迹中的界标识用于区分，不应把每个截断分支都当作已知精确值。

### 题四：竞争环境下的宝藏分配

入口在 `src/problem4_treasure.py`。

1. 用 A* 计算每一对给定位置间的最小移动代价。
2. 状态记录双方位置、剩余宝藏、双方累计收益与当前行动方。
3. 取宝藏得分为价值减移动代价；只改变行动者的位置和得分。
4. A 最大化 `Score_A-Score_B`，B 最小化同一个值。
5. 每个玩家的一次选择计一层，H=2 为 A→B，H=4 为 A→B→A→B。
6. 根层共享 alpha，避免对每个首步重置窗口而损失剪枝。

本题 A/B/T 格进入代价均为 **1**，不继承题二的目标免费规则。经过其他宝藏不自动收集；取过的宝藏格仍可通行；另一玩家不挡路；负 Gain 仍是合法行动，没有额外的“跳过回合”。

H=2 的最优行动是 T2→T3，双方分别得 2 和 3，U=-1。H=4 可以选择 T3→T1→T2→T4：A 的累计收益 -1，B 为 -4，U=3。另有等值最优响应路径，不能把一次轨迹理解为唯一策略。

宝藏按 `treasure_values` 的插入顺序枚举，官方输入是 T1、T2、T3、T4。并列时保留先访问的动作；不修改此顺序，也不启用排序或缓存优化。H=0 或宝藏取完返回当前 U，首步为 None；H 超过剩余宝藏数时取完即止。

距离矩阵存在不可达位置时明确报错，当前版本不擅自增加“无可选目标时跳过回合”的扩展规则。

## 5. Python 函数接口

在项目根目录的 Python 中使用：

```python
from src.problem1_maze import a_star_maze
from src.problem2_terrain import a_star_weighted
from src.game_tree import TreeNode, tree_from_dict, minimax_best, alpha_beta_best
from src.problem4_treasure import build_distance_matrix, solve_treasure

path = a_star_maze((0, 0), (0, 2), [["S", ".", "E"]])
cost = a_star_weighted((0, 0), (0, 2), [["S", 3, "E"]])
root = TreeNode(children=[TreeNode(value=3), TreeNode(value=5)])
score = alpha_beta_best(root)
```

宝藏题先读取 `cases/problem4.json`，将 `grid`、`positions` 传给 `build_distance_matrix`，再调用：

```python
decision = solve_treasure(matrix, treasure_values, 4, use_alpha_beta=True)
# {"best_target": "T3", "best_value": 3}
```

需要统计或轨迹时，用 `search_maze`、`search_weighted`、`evaluate_tree`、`evaluate_treasure`，读取结果的 `.stats`。前两者有 `.path`、`.cost`、`.expanded_order`，后两者有 `.trace` 及分数/决策字段。核心函数不打印、不写文件，方便后续实验脚本复用。

## 6. 统计口径

| 指标 | 定义 |
|---|---|
| A* `valid_pops` | 丢弃过期条目后的出队次数，含起点和成功目标 |
| A* `expansions` | 真正枚举邻居的次数，不含成功目标 |
| A* `stale_pops` | 丢弃的旧堆条目数 |
| A* `generated_successors` | 枚举的可通行后继候选数，包括未改善 g 的候选 |
| A* `pushes` / `heap_peak` | 入堆次数（含起点）与物理堆长度峰值 |
| 博弈 `node_visits` | 递归访问次数，含根、内部、终止节点；重复状态重复计数 |
| 博弈 `leaf_evals` | 执行终止/截断评价的次数 |
| 博弈 `cutoff_events` | 满足界条件且确实跳过剩余兄弟的次数 |
| 博弈 `pruned_branches` | 跳过的直接后继分支数，不是整个被省子树的节点总数 |

以官方数据、无缓存、默认顺序运行，基线计数应为：

| 任务 | 算法 | 访问/有效出队 | 扩展/叶评 |
|---|---|---:|---:|
| 题一 | A* 曼哈顿 | 8 | 7 次扩展 |
| 题二 | A* 修正曼哈顿 | 11 | 10 次扩展 |
| 题三 | Minimax | 15 | 8 次叶评 |
| 题三 | Alpha-Beta | 14 | 7 次叶评 |
| 题四 H=2 | Minimax | 17 | 12 次叶评 |
| 题四 H=2 | Alpha-Beta | 13 | 8 次叶评 |
| 题四 H=4 | Minimax | 65 | 24 次叶评 |
| 题四 H=4 | Alpha-Beta | 47 | 16 次叶评 |

题一较小 h 优先的并列规则，会让官方地图恰好沿最短路搜索；因此不能照搬其他实现的 16/14 节点数字。修改访问顺序或并列规则后，正确答案可以不变，节点数会变化。

`.elapsed_ms` 为一次算法搜索的耗时。A* 的网格转换/校验不在此时间内；博弈输入验证也不计入搜索时间。启用轨迹会增加开销。它不是正式基准测试，更不能据一次小样例得出某种优化“更快”的结论；后续实验需要另外控制预热、批次和计时范围。

## 7. 已有正确性检查

`tests/test_solutions.py` 使用标准库 unittest，覆盖：

- 四题官方输入、完整距离矩阵、两种博弈算法的结果和计数。
- 随机迷宫与独立 BFS 的最短步数校验。
- 含障碍/零权的随机加权地图与独立 Bellman-Ford 校验。
- 不一致启发下重新打开状态、过期堆条目、零权环、目标出队才终止。
- 随机博弈树与直接递归参考值校验；共享子树、环与结构错误。
- 枚举全部宝藏行动序列后逐层回传，独立校验随机宝藏博弈。
- 无路径、起终相同、非法地图、H=0、H 超过宝藏数、宝藏取完。
- 命令行运行、轨迹严格 JSON 序列化和负深度错误处理。

这些是正确性验证，不是后续的性能对照实验。未加入反向 Dijkstra、加权 A*、收益排序、置换表或新的截断评价函数，便于保持清楚的基础版本。

## 8. 文件结构与下一阶段

```text
src/
  astar.py                 通用 A* 引擎
  grid.py                  校验、四方向邻居与进入代价
  heuristics.py            基础启发函数
  problem1_maze.py         题一路径接口
  problem2_terrain.py      题二代价接口
  game_tree.py             题三树与博弈搜索
  problem4_treasure.py     题四距离、状态与决策
  stats.py                 统一统计
  main.py                  JSON 命令行入口
cases/                     四题官方输入
tests/                     正确性测试
results/official.json      保存的本次官方结果与计数
```

建议先按顺序读 `problem1_maze.py → astar.py → grid.py → problem2_terrain.py`，再读 `game_tree.py → problem4_treasure.py`。开启一次 `--trace`，对照自己的手算理解每次扩展或剪枝。

## 9. 已完成的题一配对对照

固定种子生成 21×21、51×51、101×101 各 30 张可达地图，障碍概率 20%；接受与拒绝输入全部保存。两种策略使用相同输入，每图每策略测 5 批，所有最短路径经独立 BFS 校验。

- 实验操作说明：[experiments/README.md](experiments/README.md)。
- 本轮结果分析：[题一_对照实验分析.md](results/problem1_heuristics/题一_对照实验分析.md)。
- 数据与图表：`results/problem1_heuristics/`；共 910 行原始批次记录、5 组 PNG/SVG 图。

生成新数据并采集新一轮（输出目录须为空）：

```powershell
python -m experiments.exp1_heuristic --out results/problem1_heuristics_new
```

复用本轮的实际地图重新测量：

```powershell
python -m experiments.exp1_heuristic --dataset results/problem1_heuristics/dataset --out results/problem1_heuristics_repeat
```

仅重绘与汇总本轮结果：

```powershell
python -m experiments.analyze_maze_heuristics --results results/problem1_heuristics
```

核心算法仍只需标准库；绘图需要 Matplotlib（见 `requirements-experiments.txt`）。本轮有效出队配对节省率中位数为 80.95%、88.88%、90.50%，API 加速中位数为 3.66、5.84、6.48 倍，但曼哈顿的堆峰值在全部随机实例上更高。结论限于当前分布和并列策略，细节及局限见结果分析。

后续按《实验二_优化方案与执行指南.md》完成其余核心对照。保持本版作为基线，每次只改变启发、访问顺序等一个因素，再判断改进是否有效。

## 10. 已完成的题二启发对照

主实验使用 30 张 31×31 无障碍地形，普通格权值 {1,3,8} 的生成概率为 {0.7,0.2,0.1}，比较零启发、原始曼哈顿和修正曼哈顿。独立反向 Dijkstra 校验所有最优代价，并逐状态检查高估、逐有向边检查一致性。

- [题二完整分析](results/problem2_heuristics/题二_对照实验分析.md)。
- 数据目录：`results/problem2_heuristics/`，包含 465 行正式批次、逐格性质审计、官方累计代价与 5 组 PNG/SVG 图。
- 主实验三种策略全部最优；原始启发有高估，修正版没有。原始与修正的有效出队在 23/30 张随机图上相同，余下仅相差一次。
- 单独保存了普通格允许 0 的边界例，明确排除在主实验正确率与性能统计之外。

```powershell
python -m experiments.exp2_weighted_terrain --out results/problem2_heuristics_new
python -m experiments.exp2_weighted_terrain --dataset results/problem2_heuristics/dataset --out results/problem2_heuristics_repeat
python -m experiments.analyze_weighted_heuristics --results results/problem2_heuristics
```

原始曼哈顿本轮能算对，不能证明它可采纳；修正版的意义是符合终点免费的代价模型，不要求它必须比原始版更快或少扩展。原始输入、性质审计与正式计时的范围见实验分析和 `experiments/README.md`。
